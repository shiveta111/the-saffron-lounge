'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Globe,
  Plus,
  Edit,
  Trash2,
  Save,
  RefreshCw,
  Languages,
  CheckCircle,
  XCircle,
  AlertTriangle
} from 'lucide-react';
import { AdvancedList, Column, FilterOption } from '@/components/ui/advanced-list';
import { useTranslation } from '@/lib/i18n';
import { toast } from 'sonner';

interface Language {
  id: string;
  code: string;
  name: string;
  nativeName: string;
  flag: string;
  isDefault: boolean;
  isActive: boolean;
}

interface Translation {
  id: string;
  key: string;
  category: string;
  translations: Record<string, string>;
  lastModified: string;
}

export default function LanguagesPage() {
  const [languages, setLanguages] = useState<Language[]>([]);
  const [translations, setTranslations] = useState<Translation[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('languages');
  const [isAddLanguageOpen, setIsAddLanguageOpen] = useState(false);
  const [isAddTranslationOpen, setIsAddTranslationOpen] = useState(false);
  const [editingLanguage, setEditingLanguage] = useState<Language | null>(null);
  const [editingTranslation, setEditingTranslation] = useState<Translation | null>(null);

  const { t, currentLanguage, setLanguage, languages: activeLanguages } = useTranslation();

  // Form states
  const [languageForm, setLanguageForm] = useState({
    code: '',
    name: '',
    nativeName: '',
    flag: '',
    isDefault: false,
    isActive: true
  });

  const [translationForm, setTranslationForm] = useState({
    key: '',
    category: 'custom',
    translations: {} as Record<string, string>
  });

  const fetchLanguages = async () => {
    try {
      const response = await fetch('/api/i18n?type=languages');
      const data = await response.json();
      if (data.success) {
        setLanguages(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch languages:', error);
      toast.error('Failed to load languages');
    }
  };

  const fetchTranslations = async () => {
    try {
      const response = await fetch('/api/i18n?type=translations');
      const data = await response.json();
      if (data.success) {
        setTranslations(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch translations:', error);
      toast.error('Failed to load translations');
    }
  };

  const fetchData = async () => {
    setLoading(true);
    await Promise.all([fetchLanguages(), fetchTranslations()]);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddLanguage = async () => {
    try {
      const response = await fetch('/api/i18n', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'language', ...languageForm })
      });

      const data = await response.json();
      if (data.success) {
        toast.success('Language added successfully');
        setIsAddLanguageOpen(false);
        setLanguageForm({ code: '', name: '', nativeName: '', flag: '', isDefault: false, isActive: true });
        fetchLanguages();
      } else {
        toast.error(data.message || 'Failed to add language');
      }
    } catch (error) {
      console.error('Failed to add language:', error);
      toast.error('Failed to add language');
    }
  };

  const handleUpdateLanguage = async () => {
    if (!editingLanguage) return;

    try {
      const response = await fetch('/api/i18n', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'language', ...languageForm })
      });

      const data = await response.json();
      if (data.success) {
        toast.success('Language updated successfully');
        setEditingLanguage(null);
        fetchLanguages();
      } else {
        toast.error(data.message || 'Failed to update language');
      }
    } catch (error) {
      console.error('Failed to update language:', error);
      toast.error('Failed to update language');
    }
  };

  const handleDeleteLanguage = async (code: string) => {
    if (!confirm('Are you sure you want to delete this language? This will remove all translations for this language.')) return;

    try {
      const response = await fetch(`/api/i18n?type=language&id=${code}`, {
        method: 'DELETE'
      });

      const data = await response.json();
      if (data.success) {
        toast.success('Language deleted successfully');
        fetchLanguages();
      } else {
        toast.error(data.message || 'Failed to delete language');
      }
    } catch (error) {
      console.error('Failed to delete language:', error);
      toast.error('Failed to delete language');
    }
  };

  const handleAddTranslation = async () => {
    try {
      const response = await fetch('/api/i18n', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'translation', ...translationForm })
      });

      const data = await response.json();
      if (data.success) {
        toast.success('Translation added successfully');
        setIsAddTranslationOpen(false);
        setTranslationForm({ key: '', category: 'custom', translations: {} });
        fetchTranslations();
      } else {
        toast.error(data.message || 'Failed to add translation');
      }
    } catch (error) {
      console.error('Failed to add translation:', error);
      toast.error('Failed to add translation');
    }
  };

  const handleUpdateTranslation = async () => {
    if (!editingTranslation) return;

    try {
      const response = await fetch('/api/i18n', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'translation', ...translationForm })
      });

      const data = await response.json();
      if (data.success) {
        toast.success('Translation updated successfully');
        setEditingTranslation(null);
        fetchTranslations();
      } else {
        toast.error(data.message || 'Failed to update translation');
      }
    } catch (error) {
      console.error('Failed to update translation:', error);
      toast.error('Failed to update translation');
    }
  };

  const handleDeleteTranslation = async (key: string) => {
    if (!confirm('Are you sure you want to delete this translation?')) return;

    try {
      const response = await fetch(`/api/i18n?type=translation&id=${key}`, {
        method: 'DELETE'
      });

      const data = await response.json();
      if (data.success) {
        toast.success('Translation deleted successfully');
        fetchTranslations();
      } else {
        toast.error(data.message || 'Failed to delete translation');
      }
    } catch (error) {
      console.error('Failed to delete translation:', error);
      toast.error('Failed to delete translation');
    }
  };

  const startEditingLanguage = (language: Language) => {
    setEditingLanguage(language);
    setLanguageForm({
      code: language.code,
      name: language.name,
      nativeName: language.nativeName,
      flag: language.flag,
      isDefault: language.isDefault,
      isActive: language.isActive
    });
  };

  const startEditingTranslation = (translation: Translation) => {
    setEditingTranslation(translation);
    setTranslationForm({
      key: translation.key,
      category: translation.category,
      translations: { ...translation.translations }
    });
  };

  const languageColumns: Column<Language>[] = [
    {
      key: 'flag',
      label: 'Flag',
      render: (value) => <span className="text-2xl">{value}</span>
    },
    {
      key: 'name',
      label: 'Name',
      sortable: true
    },
    {
      key: 'nativeName',
      label: 'Native Name',
      sortable: true
    },
    {
      key: 'code',
      label: 'Code',
      sortable: true,
      render: (value) => <code className="bg-gray-100 px-2 py-1 rounded text-sm">{value}</code>
    },
    {
      key: 'isDefault',
      label: 'Default',
      render: (value) => value ? <Badge variant="default">Default</Badge> : null
    },
    {
      key: 'isActive',
      label: 'Status',
      render: (value) => (
        <Badge variant={value ? 'default' : 'secondary'}>
          {value ? 'Active' : 'Inactive'}
        </Badge>
      )
    }
  ];

  const translationColumns: Column<Translation>[] = [
    {
      key: 'key',
      label: 'Key',
      sortable: true,
      render: (value) => <code className="bg-gray-100 px-2 py-1 rounded text-sm">{value}</code>
    },
    {
      key: 'category',
      label: 'Category',
      sortable: true,
      render: (value) => <Badge variant="outline">{value}</Badge>
    },
    {
      key: 'translations',
      label: 'Translations',
      render: (value, item) => {
        const activeLangCodes = languages.filter(l => l.isActive).map(l => l.code);
        const completedTranslations = activeLangCodes.filter(code => value[code]).length;
        return (
          <div className="flex items-center space-x-2">
            <span className="text-sm">{completedTranslations}/{activeLangCodes.length}</span>
            <div className="flex space-x-1">
              {activeLangCodes.slice(0, 3).map(code => (
                <span
                  key={code}
                  className={`w-2 h-2 rounded-full ${value[code] ? 'bg-green-500' : 'bg-gray-300'}`}
                  title={`${code}: ${value[code] || 'Not translated'}`}
                />
              ))}
              {activeLangCodes.length > 3 && (
                <span className="text-xs text-gray-500">+{activeLangCodes.length - 3}</span>
              )}
            </div>
          </div>
        );
      }
    },
    {
      key: 'lastModified',
      label: 'Last Modified',
      sortable: true,
      render: (value) => new Date(value).toLocaleDateString()
    }
  ];

  const categories = ['navigation', 'common', 'forms', 'messages', 'custom'];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Multi-Language Support</h2>
          <p className="text-gray-600 mt-1">Manage languages and translations for your CMS</p>
        </div>

        <div className="flex items-center space-x-2">
          <Select value={currentLanguage} onValueChange={setLanguage}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {activeLanguages.map((lang) => (
                <SelectItem key={lang.code} value={lang.code}>
                  {lang.flag} {lang.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button onClick={fetchData} disabled={loading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="languages" className="flex items-center">
            <Globe className="w-4 h-4 mr-2" />
            Languages
          </TabsTrigger>
          <TabsTrigger value="translations" className="flex items-center">
            <Languages className="w-4 h-4 mr-2" />
            Translations
          </TabsTrigger>
        </TabsList>

        <TabsContent value="languages" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Languages</CardTitle>
                  <CardDescription>Manage supported languages in your CMS</CardDescription>
                </div>

                <Dialog open={isAddLanguageOpen} onOpenChange={setIsAddLanguageOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Language
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Language</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="lang-code">Language Code</Label>
                          <Input
                            id="lang-code"
                            value={languageForm.code}
                            onChange={(e) => setLanguageForm({...languageForm, code: e.target.value})}
                            placeholder="en"
                          />
                        </div>
                        <div>
                          <Label htmlFor="lang-flag">Flag Emoji</Label>
                          <Input
                            id="lang-flag"
                            value={languageForm.flag}
                            onChange={(e) => setLanguageForm({...languageForm, flag: e.target.value})}
                            placeholder="🇺🇸"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="lang-name">English Name</Label>
                        <Input
                          id="lang-name"
                          value={languageForm.name}
                          onChange={(e) => setLanguageForm({...languageForm, name: e.target.value})}
                          placeholder="English"
                        />
                      </div>

                      <div>
                        <Label htmlFor="lang-native">Native Name</Label>
                        <Input
                          id="lang-native"
                          value={languageForm.nativeName}
                          onChange={(e) => setLanguageForm({...languageForm, nativeName: e.target.value})}
                          placeholder="English"
                        />
                      </div>

                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={languageForm.isActive}
                            onCheckedChange={(checked) => setLanguageForm({...languageForm, isActive: checked})}
                          />
                          <Label>Active</Label>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={languageForm.isDefault}
                            onCheckedChange={(checked) => setLanguageForm({...languageForm, isDefault: checked})}
                          />
                          <Label>Default</Label>
                        </div>
                      </div>

                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={() => setIsAddLanguageOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleAddLanguage}>
                          Add Language
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <AdvancedList
                data={languages}
                columns={languageColumns}
                onEdit={startEditingLanguage}
                onDelete={(lang) => handleDeleteLanguage(lang.code)}
                loading={loading}
                emptyMessage="No languages configured"
                actions={[
                  {
                    label: 'Set as Default',
                    icon: <CheckCircle className="w-4 h-4" />,
                    onClick: (lang) => {
                      // Handle setting as default
                      toast.success(`${lang.name} set as default language`);
                    },
                    show: (lang) => !lang.isDefault
                  }
                ]}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="translations" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Translations</CardTitle>
                  <CardDescription>Manage translation keys and their values</CardDescription>
                </div>

                <Dialog open={isAddTranslationOpen} onOpenChange={setIsAddTranslationOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Translation
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Add New Translation</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="trans-key">Translation Key</Label>
                          <Input
                            id="trans-key"
                            value={translationForm.key}
                            onChange={(e) => setTranslationForm({...translationForm, key: e.target.value})}
                            placeholder="nav.home"
                          />
                        </div>
                        <div>
                          <Label htmlFor="trans-category">Category</Label>
                          <Select
                            value={translationForm.category}
                            onValueChange={(value) => setTranslationForm({...translationForm, category: value})}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {categories.map((cat) => (
                                <SelectItem key={cat} value={cat}>
                                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <Label>Translations</Label>
                        {languages.filter(l => l.isActive).map((lang) => (
                          <div key={lang.code} className="flex items-center space-x-3">
                            <span className="w-8 text-center">{lang.flag}</span>
                            <span className="w-16 text-sm font-medium">{lang.code}</span>
                            <Input
                              value={translationForm.translations[lang.code] || ''}
                              onChange={(e) => setTranslationForm({
                                ...translationForm,
                                translations: {
                                  ...translationForm.translations,
                                  [lang.code]: e.target.value
                                }
                              })}
                              placeholder={`Translation in ${lang.name}`}
                            />
                          </div>
                        ))}
                      </div>

                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={() => setIsAddTranslationOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleAddTranslation}>
                          Add Translation
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <AdvancedList
                data={translations}
                columns={translationColumns}
                onEdit={startEditingTranslation}
                onDelete={(trans) => handleDeleteTranslation(trans.key)}
                loading={loading}
                emptyMessage="No translations configured"
                enableSearch={true}
                searchPlaceholder="Search translations..."
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Edit Language Dialog */}
      <Dialog open={!!editingLanguage} onOpenChange={() => setEditingLanguage(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Language</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-lang-code">Language Code</Label>
                <Input
                  id="edit-lang-code"
                  value={languageForm.code}
                  onChange={(e) => setLanguageForm({...languageForm, code: e.target.value})}
                  disabled // Code shouldn't be editable
                />
              </div>
              <div>
                <Label htmlFor="edit-lang-flag">Flag Emoji</Label>
                <Input
                  id="edit-lang-flag"
                  value={languageForm.flag}
                  onChange={(e) => setLanguageForm({...languageForm, flag: e.target.value})}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="edit-lang-name">English Name</Label>
              <Input
                id="edit-lang-name"
                value={languageForm.name}
                onChange={(e) => setLanguageForm({...languageForm, name: e.target.value})}
              />
            </div>

            <div>
              <Label htmlFor="edit-lang-native">Native Name</Label>
              <Input
                id="edit-lang-native"
                value={languageForm.nativeName}
                onChange={(e) => setLanguageForm({...languageForm, nativeName: e.target.value})}
              />
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={languageForm.isActive}
                  onCheckedChange={(checked) => setLanguageForm({...languageForm, isActive: checked})}
                />
                <Label>Active</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={languageForm.isDefault}
                  onCheckedChange={(checked) => setLanguageForm({...languageForm, isDefault: checked})}
                />
                <Label>Default</Label>
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setEditingLanguage(null)}>
                Cancel
              </Button>
              <Button onClick={handleUpdateLanguage}>
                Update Language
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Translation Dialog */}
      <Dialog open={!!editingTranslation} onOpenChange={() => setEditingTranslation(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Translation</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-trans-key">Translation Key</Label>
                <Input
                  id="edit-trans-key"
                  value={translationForm.key}
                  onChange={(e) => setTranslationForm({...translationForm, key: e.target.value})}
                  disabled // Key shouldn't be editable
                />
              </div>
              <div>
                <Label htmlFor="edit-trans-category">Category</Label>
                <Select
                  value={translationForm.category}
                  onValueChange={(value) => setTranslationForm({...translationForm, category: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat.charAt(0).toUpperCase() + cat.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-3">
              <Label>Translations</Label>
              {languages.filter(l => l.isActive).map((lang) => (
                <div key={lang.code} className="flex items-center space-x-3">
                  <span className="w-8 text-center">{lang.flag}</span>
                  <span className="w-16 text-sm font-medium">{lang.code}</span>
                  <Input
                    value={translationForm.translations[lang.code] || ''}
                    onChange={(e) => setTranslationForm({
                      ...translationForm,
                      translations: {
                        ...translationForm.translations,
                        [lang.code]: e.target.value
                      }
                    })}
                    placeholder={`Translation in ${lang.name}`}
                  />
                </div>
              ))}
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setEditingTranslation(null)}>
                Cancel
              </Button>
              <Button onClick={handleUpdateTranslation}>
                Update Translation
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}